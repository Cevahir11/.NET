﻿using Microsoft.EntityFrameworkCore;
using StudentPortal.Web.Models.Entities;
namespace StudentPortal.Web.Data
{
    public class ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : DbContext(options)
    {
        public DbSet<Student> Students { get; set; }
    }
}

